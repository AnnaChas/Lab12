<template>
  <nav>
    <router-link to="/">Главная</router-link> |
    <router-link to="/api">Данные API</router-link> |
    <router-link to="/form">Форма</router-link>
  </nav>
  <router-view/>
</template>

<style>
nav {
  padding: 30px;
  text-align: center;
}

nav a {
  font-weight: bold;
  color: #2c3e50;
}

nav a.router-link-exact-active {
  color: #8B1E46;
}
</style>