<template>
  <div class="api-page">
    <div class="header">
      <h1>Пользователи</h1>
    </div>
    
    <div v-if="store.loading" class="loading">
      Загрузка данных...
    </div>
    
    <div v-else id="users-container">
      <div v-for="user in store.users" :key="user.login.uuid" class="user-card">
        <img :src="user.picture.large" class="user-avatar" alt="User Avatar">
        <div class="user-info">
          <h3>{{ user.name.first }} {{ user.name.last }}</h3>
          <p>Email: {{ user.email }}</p>
          <p>Телефон: {{ user.phone }}</p>
          <p>Город: {{ user.location.city }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script setup>
import { useMainStore } from '@/stores/main'
import { onMounted } from 'vue'

const store = useMainStore()

onMounted(() => {
  store.fetchUsers()
})
</script>

<style scoped>
.api-page {
  font-family: Arial, sans-serif;
  max-width: 800px;
  margin: 0 auto;
  padding: 20px;
}

.user-card {
  border: 2px solid #8b1e46;
  padding: 15px;
  margin-bottom: 15px;
  display: flex;
  align-items: center;
  box-shadow: 0 2px 4px #727171;
}

.user-avatar {
  width: 80px;
  height: 80px;
  border-radius: 50%;
  margin-right: 20px;
  object-fit: cover;
}

.user-info h3 {
  margin: 0 0 5px 0;
  color: #8b1e46;
}

.user-info p {
  margin: 5px 0;
  color: #9e9e9e;
}

.header {
  text-align: center;
  margin-bottom: 30px;
}

.loading {
  text-align: center;
  font-style: italic;
  color: #8b1e46;
}
</style>