<template>
  <div class="form-container">
    <h2 class="form-title">Форма сбора данных</h2>
    <form @submit.prevent="submitForm">
      <div class="form-group">
        <label for="name">Имя:</label>
        <input type="text" id="name" v-model="form.name" required>
      </div>
      
      <div class="form-group">
        <label for="surname">Фамилия:</label>
        <input type="text" id="surname" v-model="form.surname" required>
      </div>
      
      <div class="form-group">
        <label for="phone">Номер телефона:</label>
        <input type="tel" id="phone" v-model="form.phone" required>
      </div>
      
      <div class="form-group">
        <label for="email">Email:</label>
        <input type="email" id="email" v-model="form.email" required>
      </div>
      
      <div class="form-group">
        <label>
          <input type="checkbox" id="agree" v-model="form.agree" required>
          Согласен на обработку персональных данных
        </label>
      </div>
      
      <button type="submit" class="submit-button">Отправить</button>
    </form>
    
    <div v-if="store.formData" class="success-message">
      Форма успешно отправлена!
    </div>
  </div>
</template>

<script setup>
import { ref } from 'vue'
import { useMainStore } from '@/stores/main'

const store = useMainStore()

const form = ref({
  name: '',
  surname: '',
  phone: '',
  email: '',
  agree: false
})

const submitForm = async () => {
  const formData = {
    name: form.value.name.toUpperCase(),
    surname: form.value.surname.toUpperCase(),
    email: form.value.email.toUpperCase(),
    phone: form.value.phone,
    agree: form.value.agree
  }
  
  await store.submitForm(formData)
  form.value = {
    name: '',
    surname: '',
    phone: '',
    email: '',
    agree: false
  }
}
</script>

<style scoped>
.form-container {
  max-width: 500px;
  margin: 20px auto;
  padding: 20px;
  border: 1px solid #9e9e9e;
}

.form-title {
  text-align: center;
  font-size: 24px;
  margin-bottom: 20px;
  color: #8B1E46;
}

.form-group {
  margin-bottom: 15px;
}

label {
  display: block;
  margin-bottom: 5px;
  font-weight: bold;
}

.submit-button {
  background-color: #8B1E46;
  color: #ffffff;
  padding: 10px 15px;
  border: none;
  font-size: 16px;
  width: 100%;
  margin-top: 10px;
}

.submit-button:hover {
  background-color: #9e9e9e;
  cursor: pointer;
}

input[type="text"],
input[type="email"],
input[type="tel"] {
  width: 100%;
  padding: 10px;
  border: 1px solid #9e9e9e;
}

.success-message {
  margin-top: 20px;
  padding: 10px;
  background-color: #dff0d8;
  color: #3c763d;
  text-align: center;
  border-radius: 4px;
}
</style>