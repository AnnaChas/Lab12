import { defineStore } from 'pinia'

export const useMainStore = defineStore('main', {
  state: () => ({
    users: [],
    formData: null,
    loading: false
  }),
  actions: {
    async fetchUsers() {
      this.loading = true
      try {
        const response = await fetch('https://randomuser.me/api/?results=5')
        const data = await response.json()
        this.users = data.results
      } catch (error) {
        console.error('Error fetching users:', error)
      } finally {
        this.loading = false
      }
    },
    async submitForm(formData) {
      try {
        const response = await fetch('https://jsonplaceholder.typicode.com/posts', {
          method: 'POST',
          body: JSON.stringify(formData),
          headers: {
            'Content-type': 'application/json; charset=UTF-8',
          },
        })
        const data = await response.json()
        this.formData = data
        return data
      } catch (error) {
        console.error('Error submitting form:', error)
      }
    }
  }
})